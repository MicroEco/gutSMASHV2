var recordData = [
    {
        "length": 229494,
        "seq_id": "GG693665.1",
        "regions": []
    }
];
var all_regions = {
    "order": []
};
var details_data = {};
