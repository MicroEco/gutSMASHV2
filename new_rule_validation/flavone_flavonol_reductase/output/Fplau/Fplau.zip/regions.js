var recordData = [
    {
        "length": 83559,
        "seq_id": "c00001_NZ_JBCL..",
        "regions": []
    }
];
var all_regions = {
    "order": []
};
var details_data = {};
